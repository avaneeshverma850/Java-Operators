
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        int a=4;
      //  int b=6%a; //% modulo operator
        int b=9;
      //  b/=3;  //Assignment operator
       // System.out.println(b);
        //Comparison operator are
        //System.out.println(6==6);
        //System.out.println(6==7);
        //System.out.println(65<6);
        //Logical operator
        //System.out.println(65<5 && 64>8);
        //System.out.println(65>7 || 56<4);
        //System.out.println(1!=1);
        //  Bitwise operator
        //System.out.println(2&3)
        System.out.println(4/1.1);

    }
}